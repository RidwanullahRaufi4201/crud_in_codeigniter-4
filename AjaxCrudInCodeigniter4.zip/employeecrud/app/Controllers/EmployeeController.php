<?php

namespace App\Controllers;
use App\Models\EmployeeModel;
use App\Models\LastJob;
use CodeIgniter\Commands\Utilities\Routes\FilterFinder;

class EmployeeController extends BaseController
{
    public function index()
    { 
        $emp=new EmployeeModel();
        $data['emp_all']=$emp->findAll();
     
        return view('Layout/index',$data);
    }
    public function add_new_emp()
    {
        $data=[
            'name'=>$this->request->getPost('name'),
            'gender'=>$this->request->getPost('gender'),
            'occupation'=>$this->request->getPost('occupation'),
            'education_level'=>$this->request->getPost('education_level'),
            'last_job'=>$this->request->getPost('last_job'),
           
        ];
         $employee=new EmployeeModel();
        $employee->insert($data);
   
       
    
    }

    public function getStudents()
    {
        $employee=new EmployeeModel();
        $data['employee']=$employee->findAll();
        return $this->response->setJSON($data);
    }

    public function delete_emp()
    {
        $id= $this->request->getPost('emp_id');
        $employee=new EmployeeModel();
        if($employee->delete($id))
        {
            return 1;
        }
        
    
    }
    public function view_emp()
    {
        $id= $this->request->getPost('emp_id');
         $employee=new EmployeeModel();
         $data['employee']=$employee->find($id);
        return $this->response->setJSON($data);
        //return $id;
    
    }
    public function edit_emp()
    {
        $id= $this->request->getPost('emp_id');
        $employee=new EmployeeModel();
        $data['employee']=$employee->find($id);
       return $this->response->setJSON($data);
        

    }

    public function update_emp()
    {
       $id=$this->request->getPost('id');
        $data=[
            
            'name'=>$this->request->getPost('name'),
            'gender'=>$this->request->getPost('gender'),
            'occupation'=>$this->request->getPost('occupation'),
            'education_level'=>$this->request->getPost('education_level'),
            'last_job'=>$this->request->getPost('last_job'),
            
        ];
       
         $employee=new EmployeeModel();
        
         $employee->update($id,$data);
         
      

    }


    public function getAllName()
    {
        $emp=new EmployeeModel();
        $emp->select('name');
        $data['name']=$emp->findAll();
        return $this->response->setJSON($data);

    }

    public function getAlldate()
    {
        $emp=new EmployeeModel();
        $emp->select('joining_date','last_job');
        $data['name']=$emp->findAll();
        return $this->response->setJSON($data);

    }
    public function getLastJob()
    {
        $emp=new EmployeeModel();
        $emp->select('last_job');
        $data['name']=$emp->findAll();
        return $this->response->setJSON($data);



    }

    public function getallemp()
    {
           $lastjob=$this->request->getPost('last_job');
           $emp=new EmployeeModel();
          
           $data['allemp']=$emp->find('last_job',$lastjob);

           return $this->response->setJSON($data);
    }


    public function getAllLastjob()
    {
          $lastJobs=new LastJob();
          $data['lastjobs']=$lastJobs->findAll();
          return $this->response->setJSON($data);
    }


    
   
}
