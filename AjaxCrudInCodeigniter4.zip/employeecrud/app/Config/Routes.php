<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('EmployeeController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'EmployeeController::index');
$routes->post('addemp/add_new_emp','EmployeeController::add_new_emp');
         
$routes->get('student/getStudents','EmployeeController::getStudents');
$routes->post('employee/delete_emp','EmployeeController::delete_emp');
$routes->post('employee/view_emp','EmployeeController::view_emp');
$routes->post('employee/edit_emp','EmployeeController::edit_emp');
$routes->post('employee/update_emp','EmployeeController::update_emp');
$routes->get('getnames/getAllName','EmployeeController::getAllName');
$routes->get('getdate/getAlldate','EmployeeController::getAlldate');
$routes->get('getdate/getLastJob','EmployeeController::getLastJob');
$routes->post('lastjob/getallemp','EmployeeController::getallemp');

$routes->get('getlastjob/getAllLastjob','EmployeeController::getAllLastjob');





//$routes->get('/','EmployeeController::show_all_emp');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
