<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script
    src="https://code.jquery.com/jquery-3.6.4.min.js"
    integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8="
    crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EmployeeManagement</title>
    <style>
      /* #example_info,.dataTables_empty,.col-md-6,#example_paginate{
        display: none;
      } */
    </style>
</head>
<body>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Employee</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" method="post" id="addnewemp">
              <div class="form-group">
                   <label  class="my-1" for="">EmployeeName</label>
                   <input type="text" id="name" class="form-control">
                   <p id="nameerror" style="display:none" class="text-danger">name is required</p>
              </div>
              <div class="form-group">
                 <label  class="my-1" for="">Gender</label>
              <select class="form-select" id="gender" aria-label="Default select example">
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
             
              </select>
              <p id="gendererror" style="display:none" class="text-danger">gender is required</p>
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Occupation</label>
                   <input type="text" id="occupation" class="form-control">
              </div>
              <p id="occupationerror" style="display:none" class="text-danger">occupation is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Education_level</label>
                   <input type="text" id="educationlevel" class="form-control">
              </div>
              <p id="educationerror" style="display:none" class="text-danger">education is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Last-Job</label>
             <select class="form-select" id="lastjob" aria-label="Default select example">
              <option value="">select last job</option>
              </select>
              </div>
              <p id="lastjoberror" style="display:none" class="text-danger">last job is required</p>
        </form>
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="addemp">Add Employee</button>
      </div>
    </div>
  </div>
</div>



<!-- Modal -->
<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Employee Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" method="post" id="addnewemp">
              <div class="form-group">
                   <label  class="my-1" for="">EmployeeName:<span  class="fw-bolder mx-2" id="name1"></span></label>
                  
                  
              </div>
              <div class="form-group">
                 <label  class="my-1" for="">Gender:<span id="gender1" class="fw-bolder mx-2"></span></label>
                
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Occupation:<span id="occupation1" class="fw-bolder mx-2"></span></label>
                 
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Education_level: <span id="educationlevel1" class="fw-bolder mx-2"></span></label>
                   
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Last-Job:<span id="lastjob1" class="fw-bolder mx-2"></span></label>
                  
              </div>
        </form>
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel3" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Employee</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" method="post" >
        <div class="form-group d-none">
                   <input type="number" id="empid" class="form-control">
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">EmployeeName</label>
                   <input type="text" id="name2" class="form-control">
                   <p id="nameerror" style="display:none" class="text-danger">name is required</p>
              </div>
              <div class="form-group">
                 <label  class="my-1" for="">Gender</label>
              <select class="form-select" id="gender2" aria-label="Default select example">
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
             
              </select>
              <p id="gendererror" style="display:none" class="text-danger">gender is required</p>
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Occupation</label>
                   <input type="text" id="occupation2" class="form-control">
              </div>
              <p id="occupationerror" style="display:none" class="text-danger">occupation is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Education_level</label>
                   <input type="text" id="educationlevel2" class="form-control">
              </div>
              <p id="educationerror" style="display:none" class="text-danger">education is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Last-Job</label>
                   <select class="form-select" id="lastjob2" aria-label="Default select example">
                       <option value="">select last job</option>
                   </select>
              </div>
              <p id="lastjoberror" style="display:none" class="text-danger">last job is required</p>
        </form>
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="editemp">Save Edit</button>
      </div>
    </div>
  </div>
</div>


<div class="p-3">
<div class="container">
       <div class="row ">
        <div class="col-md-10 my-2 mx-auto d-flex justify-content-end">
           
           <h6 class="btn btn-primary btn-sm  " data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-plus"></i> Add Employee</h3>
           </div>
           
          <!-- <div class="col-md-10 mt-4 mx-auto">
          <div class="d-flex justify-content-around my-2">
             <div>
                 <button class="btn btn-primary" id="all_record">All Records</button>
             </div>
               <div>
               <select name="" id="all-name" class="form-select">
                <option value="">Select Name</option>
            
             </select></div>
             <div>
               <select name="" id="all-date" class="form-select">
                <option value="">Joning date</option>
         
             </select></div>
             <div>
               <select name="" id="last_job" class="form-select">
                <option value="">Last Job</option>
             <
             </select></div>
             <div>
                 <button class="btn btn-primary" id="filter">Filter</button>
             </div>
             
           
    </div> -->
          <table id="example" class="table table-striped table-bordered" >
        <thead>
          
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Occupation</th>
                <th>Education-Level</th>
                <th>last-job</th>
                <th>date-of-joining</th>
                <th>Delete</th>
                <th>Edit</th>
                <th>View Details</th>
            </tr>
        </thead>
        <tbody id="all-employee">
            
      
 
   
  
    
        
        </tbody>
       
    </table>
          </div>
       
       </div>
</div>




<script>

    $(document).ready(function () {
  
       console.log('yes')
    
    loadstudents()
    $('#all_record').click(function(){
      loadstudents()
    })
    $(document).on('click','.btn-delete',function(){
                 var emp_id=$(this).closest('tr').find('.emp_id').text()
                 $.ajax({
                  method:"POST",
                  url:'employee/delete_emp',
                  data:{'emp_id':emp_id},
                  success:function(data){
                      console.log(data)
                  }
                 })
                 
    })
    $(document).on('click','.btn-edit',function(e){
                    e.preventDefault()
                 var emp_id=$(this).closest('tr').find('.emp_id').text()
                 $.ajax({
                  method:"POST",
                  url:'employee/edit_emp',
                  data:{'emp_id':emp_id},
                  success:function(data)
                  {
                     
                    
                    $.each(data,function(key,value){
                        $("#empid").val(value['id'])
                        $('#name2').val(value['name'])
                        $('#gender2').val(value['gender'])
                        $('#occupation2').val(value['occupation'])
                        $('#educationlevel2').val(value['education_level'])
                        $('#lastjob2').html(
                          //  "<option>"+"select last job"+"</option>"+
                          "<option selected value="+value['last_job']+">"+
                        
                                     value['last_job']
                        +"</option>")
                       
                    
                      })
                      loadAlljobsEdit()
                  }
                 })
                 
    })
    $(document).on('click','.btn-view',function(){
                 var emp_id=$(this).closest('tr').find('.emp_id').text()
                 $.ajax({
                  method:"POST",
                  url:'employee/view_emp',
                  data:{'emp_id':emp_id},
                  success:function(data){
                     // console.log(data.employee)
                      $.each(data,function(key,value){
                        $('#name1').text(value['name'])
                        $('#gender1').text(value['gender'])
                        $('#occupation1').text(value['occupation'])
                        $('#educationlevel1').text(value['education_level'])
                        $('#lastjob1').text(value['last_job'])
                       
                    
                      })

                  }
                 })
                
    })


    function loadstudents()
    {
         $.ajax({
          method:"GET",
          url:"student/getStudents",
          success:function(data){
            $('#all-employee').html('')  
            $.each(data.employee,function(key,value){
            $('#all-employee').append("<tr>"+ 
                "<td class='emp_id'>"+value['id'] +"</td>"+
                "<td>"+value['name'] +"</td>"+
                "<td>"+value['gender'] +"</td>"+
                "<td>"+value['occupation'] +"</td>"+
                "<td>"+value['education_level'] +"</td>"+
                "<td>"+value['last_job'] +"</td>"+
                "<td>"+value['joining_date'] +"</td>"+
                "<td> <a href='' class='btn btn-danger btn-sm  btn-delete' >"+'<i class="fa-solid fa-trash"></i>'+"</a></td>"+
                "<td> <a href='' class='btn btn-success  btn-sm btn-edit' data-bs-toggle='modal' data-bs-target='#exampleModal3'>"+' <i class="fa-regular fa-pen-to-square"></i>'+" </a></td>"+
                "<td> <a href='' class='btn btn-info btn-sm  btn-view' data-bs-toggle='modal' data-bs-target='#exampleModal2'>"+'<i class="fa-solid fa-eye text-white"></i>'+" </a></td>"
            +"</tr>")
           
          })
          $('#example').DataTable();
          }
         })
    }


    $('#addemp').click(function(e){

        var name=$('#name').val()
        var gender=$('#gender').val()
        var occupation=$('#occupation').val()
        var educationlevel=$('#educationlevel').val()
        var lastjob=$('#lastjob').val()
        var readytoSubmit=false
       

       




          data={
            'name':name,
            'gender':gender,
            'occupation':occupation,
            'education_level':educationlevel,
            'last_job':lastjob
          }

         $.ajax({
            method:"POST",
            url:"addemp/add_new_emp",
            data:data,
            success:function(data){
                  $('#exampleModal').modal('hide');
                  $('#exampleModal').find('input').val('');
                  $('#exampleModal').find('select').val('');
                  $('#all-employee').html('');
                  Swal.fire({
                   position: 'top',
                   icon: 'success',
                   title: 'Employee Added Successfully',
                   showConfirmButton: false,
                   timer: 1500
                    })
                  loadstudents()
                  
           }
            
         })
    
        

    })

   
    $("#editemp").click(function(){
     

       var id=$('#empid').val()
        var name=$('#name2').val()
        var gender=$('#gender2').val()
        var occupation=$('#occupation2').val()
        var educationlevel=$('#educationlevel2').val()
        var lastjob=$('#lastjob2').val()
      
      
        data={
            'id':id,
            'name':name,
            'gender':gender,
            'occupation':occupation,
            'education_level':educationlevel,
            'last_job':lastjob,

          }

          $.ajax({
            method:"POST",
            url:"employee/update_emp",
            data:data,
            success:function(data){
                  $('#exampleModal3').modal('hide');
                  $('#exampleModal3').find('input').val('');
                  $('#exampleModal3').find('select').val('');
                  $('#all-employee').html('');
                  Swal.fire({
                      position: 'top',
                      icon: 'success',
                      title: 'Record Edited successfully',
                      showConfirmButton: false,
                      timer: 1500
                     })
                  loadstudents()
                 
                  
           }
            
         })


       
    })

    loadAllName()
    function loadAllName()
    {
      
    $.ajax({
          method:"GET",
          url:"getnames/getAllName",
          success:function(data){
           // console.log(data)
            $.each(data.name,function(key,value){
            $('#all-name').append("<option value="+value['name']+">"+ 
                value['name'] 
            +"</option>")

          })

          }
         })
    }

    loadAllStartDate()
    function loadAllStartDate()
    {
      
    $.ajax({
          method:"GET",
          url:"getdate/getAlldate",
          success:function(data){
           // console.log(data)
            $.each(data.name,function(key,value){
            $('#all-date').append("<option value="+value['joining_date']+">"+ 
                value['joining_date'] 
            +"</option>")

          })

          }
         })
    }

    loadAllLastJob()

    function loadAllLastJob()
    {  $.ajax({
          method:"GET",
          url:"getlastjob/getAllLastjob",
          success:function(data){
            
            $.each(data.lastjobs,function(key,value){
            $('#lastjob').append("<option value="+value['role']+">"+ 
                value['role'] 
            +"</option>")
            

         })

          }
         })}

      function loadAlljobsEdit()
      {
        $.ajax({
          method:"GET",
          url:"getlastjob/getAllLastjob",
          success:function(data){
            
            $.each(data.lastjobs,function(key,value){
            $('#lastjob2').append("<option value="+value['role']+">"+ 
                value['role'] 
            +"</option>")
            

         })

          }
         })
      } 


    $("#filter").click(function(e){
      var last_job= $("#last_job").val()
   
      

       data={
              'last_job':last_job
            }
          $.ajax({
            method:"POST",
            url:"lastjob/getallemp",
           
            data:data,
            success:function(data)
            {
             // console.log(data)
            $.each(data.allemp,function(key,value){
             
              
            $('#all-employee').html("<tr>"+ 
                "<td class=' emp_id'>"+value['id'] +"</td>"+
                "<td>"+value['name'] +"</td>"+
                "<td>"+value['gender'] +"</td>"+
                "<td>"+value['occupation'] +"</td>"+
                "<td>"+value['education_level'] +"</td>"+
                "<td>"+value['last_job'] +"</td>"+
                "<td>"+value['joining_date'] +"</td>"+
                "<td> <a href='' class='btn btn-danger btn-sm  btn-delete' >Delete </a></td>"+
                "<td> <a href='' class='btn btn-success  btn-sm btn-edit' data-bs-toggle='modal' data-bs-target='#exampleModal3'>Edit </a></td>"+
                "<td> <a href='' class='btn btn-info btn-sm  btn-view' data-bs-toggle='modal' data-bs-target='#exampleModal2'>View </a></td>"
            +"</tr>")

          })

            }
          })
       





        
    })



    


  });



</script>
</body>
</html>


